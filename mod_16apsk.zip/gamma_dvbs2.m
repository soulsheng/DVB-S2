function g = gamma_dvbs2(rate) 
if rate == 2/3
    g = 3.1;
elseif rate == 3/4
    g = 2.85;
elseif rate == 5/6
    g = 2.6;
elseif rate == 8/9 
    g = 2.58;
else g = 2;
end 
    